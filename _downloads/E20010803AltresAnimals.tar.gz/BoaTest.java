/*
 * Test de la classe Boa
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class BoaTest {
    @Test
    public void testBoa_extendsAnimal() {
        Assert.assertTrue("Ha d'estendre Animal", Boa.class.getSuperclass().equals(Animal.class));
    }

    @Test
    public void testBoa_noImplementaMascota() {
        Assert.assertFalse("No ha d'implementar Mascota", Mascota.class.isAssignableFrom(Boa.class));
    }


    @Test
    public void testBoa_fesSorollResponGrrGrr() {
        Assert.assertEquals("xiu-xiu", new Boa("A").fesSoroll());
    }

    @Test
    public void testBoa_rugeixResponGrrGrr() {
        Assert.assertEquals("xiu-xiu", new Boa("A").xiuxiueja());
    }

    public static void main(String[] args) {
        JUnitCore.main(new String[]{"BoaTest"});
    }

}
