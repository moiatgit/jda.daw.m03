/*
 * Test de la classe Canari
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class CanariTest {
    @Test
    public void testCanari_extendsAnimal() {
        Assert.assertTrue("Ha d'estendre Animal", Canari.class.getSuperclass().equals(Animal.class));
    }

    @Test
    public void testCanari_implementaMascota() {
        Assert.assertTrue("Ha d'implementar Mascota", Mascota.class.isAssignableFrom(Canari.class));
    }


    @Test
    public void testCanari_fesSorollResponPiuPiu() {
        Assert.assertEquals("piu piu", new Canari("A").fesSoroll());
    }

    @Test
    public void testCanari_rugeixResponPiuPiu() {
        Assert.assertEquals("piu piu", new Canari("A").piula());
    }

    @Test
    public void testCanari_mascoteja() {
        Assert.assertEquals("piu piu", new Canari("A").mascoteja());
    }

    public static void main(String[] args) {
        JUnitCore.main(new String[]{"CanariTest"});
    }

}
