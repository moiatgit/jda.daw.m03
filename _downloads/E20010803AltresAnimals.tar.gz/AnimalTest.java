/*
 * Test de la classe Animal
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class AnimalTest {

    @Test
    public void testAnimal_ésAbstracte() {
        Assert.assertTrue("Cal definir Animal com abstracta",
                java.lang.reflect.Modifier.isAbstract(Animal.class.getModifiers()));
    }

    @Test
    public void testAnimal_fesSorollÉsAbstracte() {
        try {
            Assert.assertTrue("Cal definir com a abstracte el mètode fesSoroll()",
                    java.lang.reflect.Modifier.isAbstract(
                        Animal.class.getDeclaredMethod("fesSoroll", new Class<?>[] {}).getModifiers()));
        } catch (NoSuchMethodException e) {
            Assert.fail("Cal definir el mètode fesSoroll()");
        }
    }

    @Test
    public void testAnimal_comEtDiusResponElNom() {
        Assert.assertEquals("Renat", getAnimalGeneric().comEtDius());
    }

    @Test
    public void testAnimal_caminaResponTapTapTap() {
        Assert.assertEquals("tap tap tap", getAnimalGeneric().camina());
    }

    @Test
    public void testAnimal_mouteResponSorollITapTapTap() {
        Assert.assertEquals("soroll tap tap tap", getAnimalGeneric().moute());
    }

    @Test
    public void testAnimal_dormResponZzz() {
        Assert.assertEquals("zzz", getAnimalGeneric().dorm());
    }

    /**
     * Construeix una instància d'un animal genèric
     * @return una instància d'animal genèric
     */
    private Animal getAnimalGeneric() {
        return new Animal("Renat") {
            public String fesSoroll() { return "soroll"; }
        };
    }
    public static void main(String[] args) {
        JUnitCore.main(new String[]{"AnimalTest"});
    }
}


