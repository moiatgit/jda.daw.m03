/*
 * Test de la classe Lleo
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class LleoTest {
    @Test
    public void testLleo_extendsAnimal() {
        Assert.assertTrue("Ha d'estendre Animal", Lleo.class.getSuperclass().equals(Animal.class));
    }

    @Test
    public void testLleo_noImplementaMascota() {
        Assert.assertFalse("No ha d'implementar Mascota", Mascota.class.isAssignableFrom(Lleo.class));
    }

    @Test
    public void testLleo_fesSorollResponGrrGrr() {
        Assert.assertEquals("grr grr", new Lleo("A").fesSoroll());
    }

    @Test
    public void testLleo_rugeixResponGrrGrr() {
        Assert.assertEquals("grr grr", new Lleo("A").rugeix());
    }

    public static void main(String[] args) {
        JUnitCore.main(new String[]{"LleoTest"});
    }

}
