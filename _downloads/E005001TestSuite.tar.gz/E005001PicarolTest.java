/*
 * Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 1. El picarol
 */
import org.junit.Assert;
import org.junit.Test;
public class E005001PicarolTest {
    @Test
    public void testPicarolSonaIComptaFinsATres() {
        Picarol picarol = new Picarol();
        Assert.assertEquals(0, picarol.quantsCopsHaSonat());
        for (int i = 1; i <=3; i++) {
            picarol.sona();
            Assert.assertEquals(i, picarol.quantsCopsHaSonat());
        }
    }
}
