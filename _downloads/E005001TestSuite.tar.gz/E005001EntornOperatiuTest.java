/* Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 1. El picarol
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.JUnitCore;

public class E005001EntornOperatiuTest {
    private EntornOperatiu entornAmbGatIntern;
    private EntornOperatiu entornAmbGatExtern;
    private GatRenat renat;

    @Before
    public void start() {
        entornAmbGatIntern = new EntornOperatiu();
        renat = new GatRenat();
        entornAmbGatExtern = new EntornOperatiu(renat);
    }

    @Test
    public void testEntornOperatiuEsPotCrear() {
        Assert.assertEquals("estic dret", entornAmbGatIntern.processaEntrada("com estàs?"));
        Assert.assertEquals("dret", renat.getEstatComString());
    }

    @Test
    public void testProcessaAdeu() {
        String resposta = entornAmbGatIntern.processaEntrada("adéu");
        Assert.assertEquals("adéu", resposta);
        Assert.assertTrue(entornAmbGatIntern.demanaSortir("adéu"));
    }

    @Test
    public void testComandaDesconeguda() {
        String resposta = entornAmbGatIntern.processaEntrada("hola");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testNoConsideraCase() {
        String resposta = entornAmbGatIntern.processaEntrada("AdéU");
        Assert.assertEquals("adéu", resposta);
    }

    @Test
    public void testProcessaSeu() {
        String resposta = entornAmbGatIntern.processaEntrada("seu");
        Assert.assertEquals("m'assec", resposta);

        entornAmbGatExtern.processaEntrada("seu");
        Assert.assertEquals("assegut", renat.getEstatComString());
    }

    @Test
    public void testProcessaAixecat() {
        String resposta = entornAmbGatIntern.processaEntrada("aixeca't");
        Assert.assertEquals("no faig res", resposta); // està dret d'inici

        renat.seu();    // perquè no estigui dret
        entornAmbGatExtern.processaEntrada("aixeca't");
        Assert.assertEquals("dret", renat.getEstatComString());
    }

    @Test
    public void testProcessaEstirat() {
        String resposta = entornAmbGatIntern.processaEntrada("seu");
        Assert.assertEquals("m'assec", resposta);

        entornAmbGatExtern.processaEntrada("seu");
        Assert.assertEquals("assegut", renat.getEstatComString());
    }

    @Test
    public void testProcessaPosatPicarol() {
        String resposta = entornAmbGatIntern.processaEntrada("posa't picarol");
        Assert.assertEquals("fet", resposta);
    }

    @Test
    public void testProcessaPosatPicarolQuanJaEnTe() {
        entornAmbGatIntern.processaEntrada("posa't picarol");
        String resposta = entornAmbGatIntern.processaEntrada("posa't picarol");
        Assert.assertEquals("ja tinc picarol", resposta);
    }

    @Test
    public void testProcessaTreutePicarolQuanNoEnTe() {
        String resposta = entornAmbGatIntern.processaEntrada("treu-te picarol");
        Assert.assertEquals("no en tinc cap de picarol", resposta);
    }

    @Test
    public void testProcessaTreutePicarolQuanEnTe() {
        entornAmbGatIntern.processaEntrada("posa't picarol");
        String resposta = entornAmbGatIntern.processaEntrada("treu-te picarol");
        Assert.assertEquals("fet", resposta);
    }

    @Test
    public void testProcessaTePicarolEnComençar() {
        String resposta = entornAmbGatIntern.processaEntrada("tens picarol?");
        Assert.assertEquals("no", resposta);
    }

    @Test
    public void testProcessaTePicarolQuanJaEnTe() {
        entornAmbGatIntern.processaEntrada("posa't picarol");
        String resposta = entornAmbGatIntern.processaEntrada("tens picarol?");
        Assert.assertEquals("sí", resposta);
    }

    public static void main(String[] arrstring) {
        JUnitCore.main(new String[]{"E005001EntornOperatiuTest"});
    }
}
