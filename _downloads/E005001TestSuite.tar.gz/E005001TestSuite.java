/*
 * Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 1. El picarol
 * Suite for all the test classes in this exercise
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runner.JUnitCore;

@RunWith(Suite.class)

@Suite.SuiteClasses( { E005001PicarolTest.class, E005001GatRenatTest.class, E005001EntornOperatiuTest.class })

public class E005001TestSuite {
    public static void main(String[] arrstring) {
        JUnitCore.main(new String[]{"E005001TestSuite"});
    }
}
