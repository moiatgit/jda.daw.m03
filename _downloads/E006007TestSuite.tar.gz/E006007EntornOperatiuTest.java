/* Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 1. El picarol
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.JUnitCore;

import java.util.Arrays;

public class E006007EntornOperatiuTest {
    private EntornOperatiu entornAmbGatsIntern;
    private EntornOperatiu entornAmbGatsExtern;
    private GatRenat renat;
    private GatGarfield garfield;

    @Before
    public void start() {
        entornAmbGatsIntern = new EntornOperatiu();
        renat = new GatRenat();
        garfield = new GatGarfield();
        entornAmbGatsExtern = new EntornOperatiu(renat, garfield);
    }

    @Test
    public void testComandaDesconeguda() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat hola");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testNoConsideraCaseQuanAdeu() {
        String resposta = entornAmbGatsIntern.processaEntrada("AdéU");
        Assert.assertEquals("adéu", resposta);
        Assert.assertTrue(entornAmbGatsIntern.demanaSortir("AdéU"));
    }

    @Test
    public void testProcessaAdeu() {
        String resposta = entornAmbGatsIntern.processaEntrada("adéu");
        Assert.assertEquals("adéu", resposta);
        Assert.assertTrue(entornAmbGatsIntern.demanaSortir("adéu"));
    }


    @Test
    public void testEntornOperatiuEsPotCrear() {
        Assert.assertEquals("estic dret", entornAmbGatsIntern.processaEntrada("Renat com estàs?"));
        Assert.assertEquals("estic estirat", entornAmbGatsIntern.processaEntrada("Garfield com estàs?"));
        Assert.assertEquals("dret", renat.getEstatComString());
        Assert.assertEquals("estirat", garfield.getEstatComString());
    }

    @Test
    public void testEntornProcessaComEstasAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield com estàs? avui");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testEntornProcessaAixecatAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield aixeca't ràpid");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testEntornProcessaSeuAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield seu ràpid");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testEntornProcessaEstiratAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield estira't ràpid");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testEntornProcessaPosatPicarolAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield posa't picarol ràpid");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testEntornProcessaTreuPicarolAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield treu-te picarol ràpid");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testEntornProcessaTensPicarolAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield tens picarol? ràpid");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testEntornProcessaEstasGrasAmbParametres() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield estàs gras molt");
        Assert.assertEquals("no t'entenc", resposta);
    }

    // test Renat

    @Test
    public void testProcessaPerRenatSeu() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat seu");
        Assert.assertEquals("m'assec", resposta);

        entornAmbGatsExtern.processaEntrada("Renat seu");
        Assert.assertEquals("assegut", renat.getEstatComString());
    }

    @Test
    public void testProcessaPerRenatAixecat() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat aixeca't");
        Assert.assertEquals("no faig res", resposta); // està dret d'inici

        renat.seu();    // perquè no estigui dret
        entornAmbGatsExtern.processaEntrada("Renat aixeca't");
        Assert.assertEquals("dret", renat.getEstatComString());
    }

    @Test
    public void testProcessaPerRenatEstirat() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat estira't");
        Assert.assertEquals("m'estiro", resposta);

        entornAmbGatsExtern.processaEntrada("Renat estira't");
        Assert.assertEquals("estirat", renat.getEstatComString());
    }

    @Test
    public void testProcessaPerRenatPosatPicarol() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat posa't picarol");
        Assert.assertEquals("fet", resposta);
    }

    @Test
    public void testProcessaPerRenatPosatPicarolQuanJaEnTe() {
        entornAmbGatsIntern.processaEntrada("Renat posa't picarol");
        String resposta = entornAmbGatsIntern.processaEntrada("Renat posa't picarol");
        Assert.assertEquals("ja tinc picarol", resposta);
    }

    @Test
    public void testProcessaPerRenatTreutePicarolQuanNoEnTe() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat treu-te picarol");
        Assert.assertEquals("no en tinc cap de picarol", resposta);
    }

    @Test
    public void testProcessaPerRenatTreutePicarolQuanEnTe() {
        entornAmbGatsIntern.processaEntrada("Renat posa't picarol");
        String resposta = entornAmbGatsIntern.processaEntrada("Renat treu-te picarol");
        Assert.assertEquals("fet", resposta);
    }

    @Test
    public void testProcessaPerRenatTePicarolEnComençar() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat tens picarol?");
        Assert.assertEquals("no", resposta);
    }

    @Test
    public void testProcessaPerRenatTePicarolQuanJaEnTe() {
        entornAmbGatsIntern.processaEntrada("Renat posa't picarol");
        String resposta = entornAmbGatsIntern.processaEntrada("Renat tens picarol?");
        Assert.assertEquals("sí", resposta);
    }

    // Test Garfield

    @Test
    public void testProcessaPerGarfieldSeu() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield seu");
        Assert.assertEquals("m'assec", resposta);

        entornAmbGatsExtern.processaEntrada("Garfield seu");
        Assert.assertEquals("assegut", garfield.getEstatComString());
    }

    @Test
    public void testProcessaPerGarfieldAixecat() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield aixeca't");
        Assert.assertEquals("m'aixeco", resposta); // està estirat d'inici

        garfield.seu();    // perquè no estigui estirat
        entornAmbGatsExtern.processaEntrada("Garfield estira't");
        Assert.assertEquals("estirat", garfield.getEstatComString());
    }

    @Test
    public void testProcessaPerGarfieldEstirat() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield estira't");
        Assert.assertEquals("no faig res", resposta);

        entornAmbGatsExtern.processaEntrada("Garfield estira't");
        Assert.assertEquals("estirat", garfield.getEstatComString());
    }

    @Test
    public void testProcessaPerGarfieldPosatPicarol() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield posa't picarol");
        Assert.assertEquals("fet", resposta);
    }

    @Test
    public void testProcessaPerGarfieldPosatPicarolQuanJaEnTe() {
        entornAmbGatsIntern.processaEntrada("Garfield posa't picarol");
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield posa't picarol");
        Assert.assertEquals("ja tinc picarol", resposta);
    }

    @Test
    public void testProcessaPerGarfieldTreutePicarolQuanNoEnTe() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield treu-te picarol");
        Assert.assertEquals("no en tinc cap de picarol", resposta);
    }

    @Test
    public void testProcessaPerGarfieldTreutePicarolQuanEnTe() {
        entornAmbGatsIntern.processaEntrada("Garfield posa't picarol");
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield treu-te picarol");
        Assert.assertEquals("fet", resposta);
    }

    @Test
    public void testProcessaPerGarfieldTePicarolEnComençar() {
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield tens picarol?");
        Assert.assertEquals("no", resposta);
    }

    @Test
    public void testProcessaPerGarfieldTePicarolQuanJaEnTe() {
        entornAmbGatsIntern.processaEntrada("Garfield posa't picarol");
        String resposta = entornAmbGatsIntern.processaEntrada("Garfield tens picarol?");
        Assert.assertEquals("sí", resposta);
    }

    @Test
    public void testProcessaPerRenatEtsGrasResponNoEntenc() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat estàs gras");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testProcessaPerRenatAssignaResponNoEntenc() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat assigna cosa");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testProcessaPerRenatAprenResponNoEntenc() {
        String resposta = entornAmbGatsIntern.processaEntrada("Renat aprén molt");
        Assert.assertEquals("no t'entenc", resposta);
    }

    @Test
    public void testProcessaAssignaAmbLlistaBuida() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield assigna");
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertEquals("aha!", resposta);
        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesOriginals) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesOriginals, paraulotesTrobades));
    }

    @Test
    public void testProcessaAssignaAmbUnInsult() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield assigna insult");
        String[] paraulotesTrobades = garfield.getParaulotes();
        String[] paraulotesEsperades = { "insult" };

        Assert.assertEquals("aha!", resposta);
        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesEsperades) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesEsperades, paraulotesTrobades));
    }

    @Test
    public void testProcessaAssignaAmbDosInsults() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield assigna insult1, insult2");
        String[] paraulotesTrobades = garfield.getParaulotes();
        String[] paraulotesEsperades = new String[] { "insult1", "insult2" };

        Assert.assertEquals("aha!", resposta);
        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesEsperades) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesEsperades, paraulotesTrobades));
    }

    @Test
    public void testProcessaAssignaAmbUnInsultIncorrecte() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield assigna insult1, ,insult2");
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertEquals("aha!", resposta);
        Assert.assertTrue(Arrays.equals(paraulotesOriginals, paraulotesTrobades));
    }

    @Test
    public void testProcessaAprenAmbLlistaBuida() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield assigna");
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertEquals("aha!", resposta);
        Assert.assertTrue(Arrays.equals(paraulotesOriginals, paraulotesTrobades));
    }

    @Test
    public void testProcessaAprenAmbUnInsult() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield aprén nova paraulota");
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertEquals("aha!", resposta);
        Assert.assertEquals(paraulotesOriginals.length + 1, paraulotesTrobades.length);
        Assert.assertEquals("nova paraulota", paraulotesTrobades[paraulotesTrobades.length-1]);
    }

    @Test
    public void testProcessaAprenAmbDosInsults() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield aprén nova paraulota 1, nova paraulota 2");
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertEquals("aha!", resposta);
        Assert.assertEquals(paraulotesOriginals.length + 2, paraulotesTrobades.length);
        Assert.assertEquals("nova paraulota 2", paraulotesTrobades[paraulotesTrobades.length-1]);
        Assert.assertEquals("nova paraulota 1", paraulotesTrobades[paraulotesTrobades.length-2]);
    }

    @Test
    public void testProcessaAprenAmbUnInsultIncorrecte() {
        String[] paraulotesOriginals = garfield.getParaulotes();
        String resposta = entornAmbGatsExtern.processaEntrada("Garfield assigna insult1, ,insult2");
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertEquals("aha!", resposta);
        Assert.assertTrue(Arrays.equals(paraulotesOriginals, paraulotesTrobades));
    }

    @Test
    public void testProcessaEtsGrasMostraInsultsEnOrdre() {
        String[] paraulotesOriginals = garfield.getParaulotes();

        for (int i=0; i<1; i++) {
            for (String paraulota: paraulotesOriginals) {
                String resposta = entornAmbGatsExtern.processaEntrada("Garfield estàs gras");
                Assert.assertEquals(paraulota, resposta);
            }
        }
    }


    public static void main(String[] arrstring) {
        JUnitCore.main(new String[]{"E006007EntornOperatiuTest"});
    }
}
