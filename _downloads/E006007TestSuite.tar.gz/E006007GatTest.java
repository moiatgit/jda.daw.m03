/* Secció: Elements essencials
 * Entrada: Relacions: herència
 * Exercici 7. Amic garfield
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class E006007GatTest {
    @Test
    public void testGatNeixEstirat() {
        Assert.assertEquals("estirat", new Gat("Garfield").getEstatComString());
    }
    @Test
    public void testGatPotEstarDret() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("dret");
        Assert.assertEquals("dret", gat.getEstatComString());
    }
    @Test
    public void testGatPotEstarAssegut() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("assegut");
        Assert.assertEquals("assegut", gat.getEstatComString());
    }
    @Test
    public void testGatPotEstirarse() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("assegut");
        gat.setEstat("estirat");
        Assert.assertEquals("estirat", gat.getEstatComString());
    }
    @Test
    public void testRenaNoPotCorrer() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("corrent");
        Assert.assertEquals("estirat", gat.getEstatComString());
    }
    @Test
    public void testGatNeixViu() {
        Assert.assertTrue(new Gat("Garfield").estaViu());
    }
    @Test
    public void testGatNoEstaViuAmbZeroVides() {
        Gat gat = new Gat("Garfield");
        gat.setVides(0);
        Assert.assertFalse(gat.estaViu());
    }
    @Test
    public void testGatDiuEstarEstiratEnNeixer() {
        Assert.assertTrue(new Gat("Garfield").estaEstirat());
    }
    @Test
    public void testGatDiuNoEstarEstiratQuanDret() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("dret");
        Assert.assertFalse(gat.estaEstirat());
    }
    @Test
    public void testGatDiuEstarAssegutQuanHoEsta() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("assegut");
        Assert.assertTrue(gat.estaAssegut());
    }
    @Test
    public void testGatDiuNoEstarAssegutQuanNoHoEsta() {
        Assert.assertFalse(new Gat("Garfield").estaAssegut());
    }
    @Test
    public void testGatDiuEstarDretQuanHoEsta() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("dret");
        Assert.assertTrue(gat.estaDret());
    }
    @Test
    public void testGatDiuNoEstarDretQuanNoHoEsta() {
        Assert.assertFalse(new Gat("Garfield").estaDret());
    }

    @Test
    public void testGatSEstira() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("dret");
        String resposta = gat.estirat();
        Assert.assertTrue(gat.estaEstirat());
        Assert.assertEquals("m'estiro", resposta);
    }
    @Test
    public void testGatSeu() {
        Gat gat = new Gat("Garfield");
        String resposta = gat.seu();
        Assert.assertTrue(gat.estaAssegut());
        Assert.assertEquals("m'assec", resposta);
    }
    @Test
    public void testGatSAixeca() {
        Gat gat = new Gat("Garfield");
        String resposta = gat.aixecat();
        Assert.assertTrue(gat.estaDret());
        Assert.assertEquals("m'aixeco", resposta);
    }
    @Test
    public void testGatNoFaResQuanDemanemQueSEstiriIJaHoEstava() {
        Gat gat = new Gat("Garfield");
        String resposta = gat.estirat();
        Assert.assertEquals("no faig res", resposta);
    }
    @Test
    public void testGatNoFaResQuanDemanemQueSAsseguiIJaHoEstava() {
        Gat gat = new Gat("Garfield");
        gat.seu();
        String resposta = gat.seu();
        Assert.assertEquals("no faig res", resposta);
    }

    @Test
    public void testGatNoFaResQuanDemanemQueSAixequiIJaHoEstava() {
        Gat gat = new Gat("Garfield");
        gat.aixecat();
        String resposta = gat.aixecat();
        Assert.assertEquals("no faig res", resposta);
    }

    @Test
    public void testGatCanviaEstatAmbGatEstat() {
        Gat gat = new Gat("Garfield");
        gat.setEstat(GatEstat.ESTIRAT);
        gat.setEstat(GatEstat.ASSEGUT);
        gat.setEstat(GatEstat.DRET);
        Assert.assertEquals(GatEstat.DRET, gat.getEstat());
    }

    @Test
    public void testGatNeixDret() {
        Gat gat = new Gat("Garfield", GatEstat.DRET);
        Assert.assertEquals(GatEstat.DRET, gat.getEstat());
    }

    @Test
    public void testGatNoTePicarolEnNeixer() {
        Gat gat = new Gat("Garfield");
        Assert.assertFalse(gat.tePicarol());
    }

    @Test
    public void testGatAcceptaPicarol() {
        Gat gat = new Gat("Garfield");
        Picarol picarol = new Picarol();
        Picarol anticPicarol = gat.posaPicarol(picarol);
        Assert.assertNull(anticPicarol);
    }

    @Test
    public void testGatRetornaPicarolAnteriorEnAcceptarUnDeNou() {
        Gat gat = new Gat("Garfield");
        Picarol picarol1 = new Picarol();
        Picarol picarol2 = new Picarol();
        gat.posaPicarol(picarol1);
        Picarol anticPicarol = gat.posaPicarol(picarol2);
        Assert.assertEquals(picarol1, anticPicarol);
    }

    @Test
    public void testGatTreuPicarol() {
        Gat gat = new Gat("Garfield");
        Picarol picarol = new Picarol();
        gat.posaPicarol(picarol);
        Picarol anticPicarol = gat.treuPicarol();
        Assert.assertEquals(picarol, anticPicarol);
    }

    @Test
    public void testGatFaSonarElPicarolQuanEsMou() {
        Gat gat = new Gat("Garfield");
        Picarol picarol = new Picarol();
        gat.posaPicarol(picarol);
        gat.seu();
        Assert.assertEquals(1, picarol.quantsCopsHaSonat());
        gat.aixecat();
        Assert.assertEquals(2, picarol.quantsCopsHaSonat());
        gat.estirat();
        Assert.assertEquals(3, picarol.quantsCopsHaSonat());
    }

    @Test
    public void testGatNoFaSonarElPicarolQuanNoEsMou() {
        Gat gat = new Gat("Garfield", GatEstat.ESTIRAT);
        Picarol picarol = new Picarol();
        gat.posaPicarol(picarol);
        gat.estirat();    // no ha de sonar
        Assert.assertEquals(0, picarol.quantsCopsHaSonat());
        gat.aixecat();
        gat.aixecat();
        Assert.assertEquals(1, picarol.quantsCopsHaSonat());
        gat.seu();
        gat.seu();
        Assert.assertEquals(2, picarol.quantsCopsHaSonat());
    }

    @Test
    public void testGatTeElsUllsTancatsQuanNeixEstirat() {
        Gat gat = new Gat("Garfield");
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeUllDretObertIUllEsquerreTancatQuanNeixAssegut() {
        Gat gat = new Gat("Garfield", GatEstat.ASSEGUT);
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeElsUllsObertsQuanNeixDret() {
        Gat gat = new Gat("Garfield", GatEstat.DRET);
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeElsUllsTancatsQuanEstirat() {
        Gat gat = new Gat("Garfield", GatEstat.DRET);
        gat.estirat();
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeUllDretObertIUllEsquerreTancatQuanSeu() {
        Gat gat = new Gat("Garfield");
        gat.seu();
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeUllsObertsQuanAixecat() {
        Gat gat = new Gat("Garfield");
        gat.aixecat();
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeElsUllsTancatsQuanSetEstatEstirat() {
        Gat gat = new Gat("Garfield", GatEstat.DRET);
        gat.setEstat(GatEstat.ESTIRAT);
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeUllDretObertIUllEsquerreTancatQuanSetEstatAssegut() {
        Gat gat = new Gat("Garfield");
        gat.setEstat(GatEstat.ASSEGUT);
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeUllsObertsQuanSetEstatDret() {
        Gat gat = new Gat("Garfield");
        gat.setEstat(GatEstat.DRET);
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeElsUllsTancatsQuanSetEstatEstiratAmbString() {
        Gat gat = new Gat("Garfield", GatEstat.DRET);
        gat.setEstat("estirat");
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeUllDretObertIUllEsquerreTancatQuanSetEstatAssegutAmbString() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("assegut");
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testGatTeUllsObertsQuanSetEstatDretAmbString() {
        Gat gat = new Gat("Garfield");
        gat.setEstat("dret");
        UllDeGat ullDret = gat.getUllDret();
        UllDeGat ullEsquerre = gat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testGatGetUllsLliurenUnaCopia() {
        Gat gat = new Gat("Garfield");
        UllDeGat ullDretInicial = gat.getUllDret();
        UllDeGat ullEsquerreInicial = gat.getUllEsquerre();

        ullDretInicial.obret();
        ullEsquerreInicial.obret();

        UllDeGat ullDretFinal = gat.getUllDret();
        UllDeGat ullEsquerreFinal = gat.getUllEsquerre();

        Assert.assertFalse("L'ull dret s'esperava tancat", ullDretFinal.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerreFinal.estasObert());
    }

    @Test
    public void testGatNoDisposaDeConstructorPerDefecte() {
        Assert.assertFalse("Gat no ha de definir constructor per defecte",
                TestUtils.hasAPublicConstructorWithTypeNamesAsParameters(Gat.class, new String[0]));
    }

    @Test
    public void testGatConstructorDefecteAmbNomValidAnomenaElGatAmbAquestNom() {
        String nomEsperat = "Garfield";
        Gat gat = new Gat(nomEsperat);
        Assert.assertEquals(nomEsperat, gat.getNom());
    }

    @Test
    public void testGatConstructorDefecteAmbNomNulAnomenaElGatDesconegut() {
        String nomEsperat = "desconegut";
        Gat gat = new Gat(null);
        Assert.assertEquals(nomEsperat, gat.getNom());
    }

    @Test
    public void testGatConstructorDefecteAmbNomBuitAnomenaElGatDesconegut() {
        String nomEsperat = "desconegut";
        Gat gat = new Gat("");
        Assert.assertEquals(nomEsperat, gat.getNom());
    }

    @Test
    public void testGatConstructorEspecificAmbNomValidAnomenaElGatAmbAquestNom() {
        String nomEsperat = "Garfield";
        Gat gat = new Gat(nomEsperat, GatEstat.DRET);
        Assert.assertEquals(nomEsperat, gat.getNom());
    }

    @Test
    public void testGatConstructorEspecificAmbNomNulAnomenaElGatDesconegut() {
        String nomEsperat = "desconegut";
        Gat gat = new Gat(null, GatEstat.DRET);
        Assert.assertEquals(nomEsperat, gat.getNom());
    }

    @Test
    public void testGatConstructorEspecificAmbNomBuitAnomenaElGatDesconegut() {
        String nomEsperat = "desconegut";
        Gat gat = new Gat("", GatEstat.DRET);
        Assert.assertEquals(nomEsperat, gat.getNom());
    }


    public static void main(String[] args) {
        JUnitCore.main(new String[]{"E006007GatTest"});
    }
}

