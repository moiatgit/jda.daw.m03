/* Secció: Elements essencials
 * Entrada: Relacions: herència
 * Exercici 7. Amic garfield
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class E006007GatRenatTest {

    @Test
    public void testGatRenatEsSubclasseDeGat() {
        Assert.assertTrue("GatRenat ha d'estendre Gat", TestUtils.subclassExtendsClass(GatRenat.class, Gat.class));
    }

    @Test
    public void testGatRenatNoRedefineixMetodesHeretats() {

        String[] nomMetodesDeGat = {
            "getNom",
            "getVides",
            "setVides",
            "getEstatComString",
            "getEstat",
            "setEstat",
            "setEstat",
            "estaViu",
            "estaEstirat",
            "estaAssegut",
            "estaDret",
            "estirat",
            "seu",
            "aixecat",
            "tePicarol",
            "posaPicarol",
            "treuPicarol",
            "getUllDret",
            "getUllEsquerre" };

        Assert.assertFalse("GatRenat no ha de redefinir els mètodes de Gat", TestUtils.definesAnyNonPrivateNonStaticMethodOfArray(GatRenat.class, nomMetodesDeGat));
    }

    @Test
    public void testGatRenatAmbConstructorPerDefecteTeComANomRenat() {
        GatRenat renat = new GatRenat();
        Assert.assertEquals("Renat", renat.getNom());
    }

    @Test
    public void testGatRenatAmbConstructorEspecificTeComANomRenat() {
        GatRenat renat = new GatRenat(GatEstat.DRET);
        Assert.assertEquals("Renat", renat.getNom());
    }

    @Test
    public void testGatRenatNoDefineixConstructorEspecificPerConeixerElNom() {
        Assert.assertFalse("GatRenat no ha de definir constructor específic per recollir el nom",
                TestUtils.hasAPublicConstructorWithTypeNamesAsParameters(GatRenat.class, new String[] {"java.lang.String"}));
    }


    public static void main(String[] args) {
        JUnitCore.main(new String[]{"E006007GatRenatTest"});
    }

}

