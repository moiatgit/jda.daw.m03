/*
 * A bunch of testing utilities
 *
 * This class is not aimed to be understood by M03 Students so, if you're one of them but have
 * curiosity, just take it easy while studying this code.
 */

import java.lang.reflect.Method;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

class TestUtils {
    /**
     * Returns true if the name of at least one public method defined by the given class equals to
     * one of the methods in publicMethodsName array
     */
    static boolean definesAnyNonPrivateNonStaticMethodOfArray(Class<?> classInstance, String[] publicMethodsName) {
        Set<String> definedMethods = convertSetOfMethodsToSetOfNamesOfMethods(getDirectNonPrivateNonStaticMethodsInClassAsSet(classInstance));
        Set<String> expectedMethods = new HashSet<>(Arrays.asList(publicMethodsName));
        definedMethods.retainAll(expectedMethods);
        return ! (definedMethods.isEmpty());
    }

    /**
     * Returns true when subclass extends superclass
     */
    static boolean subclassExtendsClass(Class<?> subclass, Class<?> superclass) {
        return subclass.getSuperclass().equals(superclass);
    }

    /**
     * Returns a set containing all the non private and non static methods defined in the given
     * class (not inherited methods) */
    static Set<Method> getDirectNonPrivateNonStaticMethodsInClassAsSet(Class<?> classInstance) {
        Set<Method> set = new HashSet<>();
        for (Method method: classInstance.getDeclaredMethods()) {
            if (Modifier.isPrivate(method.getModifiers())) { continue; }
            if (Modifier.isStatic(method.getModifiers())) { continue; }
            set.add(method);
        }
        return set;
    }

    /**
     * Returns a set containing the names of the methods defined in the given set of methods.
     * Be aware of method overloading when using this method.
     * @param methodSet: the set of methods from where the names will be extracted. This sets, nor
     *                   its contents, will be modified by this method.
     */
    static Set<String> convertSetOfMethodsToSetOfNamesOfMethods(Set<Method> methodSet) {
        Set<String> set = new HashSet<>();
        for (Method method: methodSet) {
            set.add(method.getName());
        }
        return set;
    }

    /**
     * Returns true if the given class has a public constructor with the specified types as params
     * Note: if expectedTypeNames is an empty array, the method checks for the default constructor
     * @param expectedTypeNames is an array (possibly empty) of non null non empty strings
     *                          each one representing the name of a type
     */
    static boolean hasAPublicConstructorWithTypeNamesAsParameters(Class<?> classInstance, String[] expectedTypeNames) {
        for (Constructor constructor: classInstance.getDeclaredConstructors()) {
            if (Modifier.isPrivate(constructor.getModifiers())) { continue; }
            Class<?>[] typesFound = constructor.getParameterTypes();
            if (typesFound.length != expectedTypeNames.length) { continue; }
            boolean typesMatch = true;
            for (int i=0; i<typesFound.length; i++) {
                if (! typesFound[i].getName().equals(expectedTypeNames[i])) {
                    typesMatch = false;
                    break;
                }
            }
            if (typesMatch) { return true; }
        }
        return false;
    }

}
