/* Secció: Elements essencials
 * Entrada: Relacions: herència
 * Exercici 7. Amic garfield
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

import java.util.Arrays;

public class E006007GatGarfieldTest {

    @Test
    public void testGatGarfieldEsSubclasseDeGat() {
        Assert.assertTrue("GatGarfield ha d'estendre Gat", TestUtils.subclassExtendsClass(GatGarfield.class, Gat.class));
    }

    @Test
    public void testGatGarfieldNoRedefineixMetodesHeretats() {

        String[] nomMetodesDeGat = {
            "getNom",
            "getVides",
            "setVides",
            "getEstatComString",
            "getEstat",
            "setEstat",
            "setEstat",
            "estaViu",
            "estaEstirat",
            "estaAssegut",
            "estaDret",
            "estirat",
            "seu",
            "aixecat",
            "tePicarol",
            "posaPicarol",
            "treuPicarol",
            "getUllDret",
            "getUllEsquerre" };

        Assert.assertFalse("GatGarfield no ha de redefinir els mètodes de Gat", TestUtils.definesAnyNonPrivateNonStaticMethodOfArray(GatGarfield.class, nomMetodesDeGat));
    }

    @Test
    public void testGatGarfieldAmbConstructorPerDefecteTeComANomGarfield() {
        GatGarfield garfield = new GatGarfield();
        Assert.assertEquals("Garfield", garfield.getNom());
    }

    @Test
    public void testGatGarfieldNoDefineixConstructorEspecificPerConeixerElNom() {
        Assert.assertFalse("GatGarfield no ha de definir constructor específic per recollir el nom",
                TestUtils.hasAPublicConstructorWithTypeNamesAsParameters(GatGarfield.class, new String[] {"java.lang.String"}));
    }

    @Test
    public void testGatGarfieldNoDefineixConstructorEspecificPerIndicarEstatInicial() {
        Assert.assertFalse(
                TestUtils.hasAPublicConstructorWithTypeNamesAsParameters(
                    GatGarfield.class,
                    new String[] {"GatEstat"}
                    )
                );
        Assert.assertFalse(
                TestUtils.hasAPublicConstructorWithTypeNamesAsParameters(
                    GatGarfield.class,
                    new String[] {"GatEstat", "[Ljava.lang.String;"}
                    )
                );
        Assert.assertFalse(
                TestUtils.hasAPublicConstructorWithTypeNamesAsParameters(
                    GatGarfield.class,
                    new String[] {"[Ljava.lang.String;", "GatEstat"}
                    )
                );
    }


    @Test
    public void testGarfieldAssignaAcceptaLlistaValidaDeParaulotesAmbUnaEntrada(){
        GatGarfield garfield = new GatGarfield();
        String[] paraulotesAssignades = new String[] { "insult" };
        garfield.setParaulotes(paraulotesAssignades);
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesAssignades) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesAssignades, paraulotesTrobades));
    }

    @Test
    public void testGarfieldAssignaAcceptaLlistaValidaDeParaulotesAmbDosEntrada(){
        GatGarfield garfield = new GatGarfield();
        String[] paraulotesAssignades = new String[] { "insult1", "insult2" };
        garfield.setParaulotes(paraulotesAssignades);
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesAssignades) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesAssignades, paraulotesTrobades));
    }

    @Test
    public void testGarfieldAssignaRebutjaLlistaDeParaulotesAmbCapEntrada(){
        GatGarfield garfield = new GatGarfield();
        String[] paraulotesOriginals = garfield.getParaulotes();
        String[] paraulotesAssignades = new String[] {};
        garfield.setParaulotes(paraulotesAssignades);
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesOriginals) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesOriginals, paraulotesTrobades));
    }

    @Test
    public void testGarfieldAssignaRebutjaLlistaDeParaulotesAmbEntradaBuida(){
        GatGarfield garfield = new GatGarfield();
        String[] paraulotesOriginals = garfield.getParaulotes();
        garfield.setParaulotes(new String[] { "insult1", "", "insult2" });
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(Arrays.equals(paraulotesOriginals, paraulotesTrobades));
    }

    @Test
    public void testGarfieldAssignaRebutjaLlistaDeParaulotesAmbEntradaNulla(){
        GatGarfield garfield = new GatGarfield();
        String[] paraulotesOriginals = garfield.getParaulotes();
        garfield.setParaulotes(new String[] { "insult1", null, "insult2" });
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(Arrays.equals(paraulotesOriginals, paraulotesTrobades));
    }

    @Test
    public void testGarfieldConstructorEspecificAcceptaLlistaValidaDeParaulotesAmbUnaEntrada(){
        String[] paraulotesAssignades = new String[] { "insult" };
        GatGarfield garfield = new GatGarfield(paraulotesAssignades);
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesAssignades) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesAssignades, paraulotesTrobades));
    }

    @Test
    public void testGarfieldConstructorEspecificAcceptaLlistaValidaDeParaulotesAmbDosEntrada(){
        String[] paraulotesAssignades = new String[] { "insult1", "insult2" };
        GatGarfield garfield = new GatGarfield(paraulotesAssignades);
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(
                "S'esperava " + Arrays.asList(paraulotesAssignades) + 
                " però trobat " + Arrays.asList(paraulotesTrobades),
                Arrays.equals(paraulotesAssignades, paraulotesTrobades));
    }

    @Test
    public void testGarfieldConstructorEspecificRebutjaLlistaDeParaulotesAmbCapEntrada(){
        GatGarfield garfield = new GatGarfield(new String[] {});
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(Arrays.equals(new GatGarfield().getParaulotes(), paraulotesTrobades));
    }

    @Test
    public void testGarfieldConstructorEspecificRebutjaLlistaDeParaulotesAmbEntradaBuida(){
        GatGarfield garfield = new GatGarfield(new String[] { "insult1", "", "insult2" });
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(Arrays.equals(new GatGarfield().getParaulotes(), paraulotesTrobades));
    }

    @Test
    public void testGarfieldConstructorEspecificRebutjaLlistaDeParaulotesAmbEntradaNulla(){
        GatGarfield garfield = new GatGarfield(new String[] { "insult1", null, "insult2" });
        String[] paraulotesTrobades = garfield.getParaulotes();

        Assert.assertTrue(Arrays.equals(new GatGarfield().getParaulotes(), paraulotesTrobades));
    }

    @Test
    public void testGarfieldConstructorDefecteAmbMinimDeuParaulotesValides() {
        GatGarfield garfield = new GatGarfield();
        String[] paraulotesTrobades = garfield.getParaulotes();
        Assert.assertFalse(paraulotesTrobades == null);
        Assert.assertTrue(paraulotesTrobades.length >= 10);
        for (String str: paraulotesTrobades) {
            Assert.assertFalse(str == null);
            Assert.assertFalse(str.isEmpty());
        }
    }

    @Test
    public void testGarfield_FesUnaEntremaliadura_retornaSeqüencialmentLesParaulotesIEnAcavarTornaAComençar() {
        String[] paraulotes = new String[] { "insult1", "insult2", "insult3" };
        GatGarfield garfield = new GatGarfield(paraulotes);
        for (int cops=0; cops<3; cops++) {
            for (String paraulota: paraulotes) {
                Assert.assertEquals(paraulota, garfield.fesUnaEntremaliadura());
            }
        }
    }


    public static void main(String[] args) {
        JUnitCore.main(new String[]{"E006007GatGarfieldTest"});
    }

}

