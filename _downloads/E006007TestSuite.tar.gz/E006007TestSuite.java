/*
 * Secció: Elements essencials
 * Entrada: Relacions: herència
 * Exercici 7. Amic garfield
 * Suite for all the test classes in this exercise
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runner.JUnitCore;

@RunWith(Suite.class)

@Suite.SuiteClasses( { 
    E006007UllDeGatTest.class,
    E006007PicarolTest.class,
    E006007GatRenatTest.class,
    E006007GatGarfieldTest.class,
    E006007GatTest.class,
    E006007EntornOperatiuTest.class 
})

public class E006007TestSuite {
    public static void main(String[] arrstring) {
        JUnitCore.main(new String[]{"E006007TestSuite"});
    }
}
