/* Secció: Elements essencials
 * Entrada: Relacions: herència
 * Exercici 7. Amic garfield
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class E006007UllDeGatTest {
    @Test
    public void testUllDeGatNeixTancatPerDefecte() {
        UllDeGat ull = new UllDeGat();
        Assert.assertFalse(ull.estasObert());
    }
    @Test
    public void testUllDeGatNeixObertAmbConstructorEspecific() {
        UllDeGat ull = new UllDeGat(true);
        Assert.assertTrue(ull.estasObert());
    }
    @Test
    public void testUllDeGatResponCorrectamentQuanObre() {
        UllDeGat ull = new UllDeGat();
        String resposta = ull.obret();
        Assert.assertTrue(ull.estasObert());
        Assert.assertEquals("nyeek", resposta);
    }
    @Test
    public void testUllDeGatResponCorrectamentQuanTanca() {
        UllDeGat ull = new UllDeGat(true);
        String resposta = ull.tancat();
        Assert.assertFalse(ull.estasObert());
        Assert.assertEquals("plonx", resposta);
    }
    @Test
    public void testUllDeGatNoResponQuanLiDemanenObretIJaObert() {
        UllDeGat ull = new UllDeGat(true);
        String resposta = ull.obret();
        Assert.assertTrue(ull.estasObert());
        Assert.assertTrue(resposta.isEmpty());
    }
    @Test
    public void testUllDeGatNoResponQuanLiDemanenTancarIJaTancat() {
        UllDeGat ull = new UllDeGat();
        String resposta = ull.tancat();
        Assert.assertFalse(ull.estasObert());
        Assert.assertTrue(resposta.isEmpty());
    }
}

