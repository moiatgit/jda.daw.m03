public class UsaAnimals {
    public static void main(String[] args) {

        // creem uns quants animals
        Gos fido = new Gos("Fido");
        Gat renat = new Gat("Renat");
        Canari piolin = new Canari("Piolin");
        Lleo leoncio = new Lleo("Leoncio el León");
        Boa picara = new Boa("Pícara Biborita");
        Animal[] animals = { fido, renat, piolin, leoncio, picara };

        // fem que cada animal faci totes les accions d'animal
        for (Animal animal: animals) {
            System.out.println("\"" + animal.comEtDius() + "\".camina(): " + animal.camina());
            System.out.println("\"" + animal.comEtDius() + "\".fesSoroll(): " + animal.fesSoroll());
            System.out.println("\"" + animal.comEtDius() + "\".moute(): " + animal.moute());
            System.out.println("\"" + animal.comEtDius() + "\".dorm(): " + animal.dorm());
            System.out.println();
        }

        // fem que cada animal faci les accions específiques
        System.out.println("\"" + fido.comEtDius() + "\".borda(): " + fido.borda());
        System.out.println("\"" + renat.comEtDius() + "\".miola(): " + renat.miola());
        System.out.println("\"" + piolin.comEtDius() + "\".piula(): " + piolin.piula());
        System.out.println("\"" + leoncio.comEtDius() + "\".rugeix(): " + leoncio.rugeix());
        System.out.println("\"" + picara.comEtDius() + "\".xiuxiueja(): " + picara.xiuxiueja());
    }
}
