/*
 * Test de la classe Gat
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class GatTest {
    @Test
    public void testGat_extendsAnimal() {
        Assert.assertTrue("Ha d'estendre Animal", Gat.class.getSuperclass().equals(Animal.class));
    }

    @Test
    public void testGat_fesSorollResponMeeu() {
        Assert.assertEquals("meeu", new Gat("R").fesSoroll());
    }

    @Test
    public void testGat_miolaResponMeeu() {
        Assert.assertEquals("meeu", new Gat("R").miola());
    }

    public static void main(String[] args) {
        JUnitCore.main(new String[]{"GatTest"});
    }

}
