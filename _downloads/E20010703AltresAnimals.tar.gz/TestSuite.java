/*
 * Test suite per l'exercici dels altres animals (abstractes)
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runner.JUnitCore;

@RunWith(Suite.class)

@Suite.SuiteClasses( { 
    AnimalTest.class,
    GatTest.class,
    GosTest.class,
    CanariTest.class,
    LleoTest.class,
    BoaTest.class
})

public class TestSuite {
    public static void main(String[] arrstring) {
        JUnitCore.main(new String[]{"TestSuite"});
    }
}

