/*
 * Test de la classe Gos
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class GosTest {
    @Test
    public void testGat_extendsAnimal() {
        Assert.assertTrue("Ha d'estendre Animal", Gos.class.getSuperclass().equals(Animal.class));
    }

    @Test
    public void testGos_fesSorollResponBofBof() {
        Assert.assertEquals("bof bof", new Gos("A").fesSoroll());
    }

    @Test
    public void testGos_bordaResponBofBof() {
        Assert.assertEquals("bof bof", new Gos("A").borda());
    }

    public static void main(String[] args) {
        JUnitCore.main(new String[]{"GosTest"});
    }
}
