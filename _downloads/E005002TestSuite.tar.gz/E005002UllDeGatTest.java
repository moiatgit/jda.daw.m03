/* Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 2. Els ulls de gat
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class E005002UllDeGatTest {
    @Test
    public void testUllDeGatNeixTancatPerDefecte() {
        UllDeGat ull = new UllDeGat();
        Assert.assertFalse(ull.estasObert());
    }
    @Test
    public void testUllDeGatNeixObertAmbConstructorEspecific() {
        UllDeGat ull = new UllDeGat(true);
        Assert.assertTrue(ull.estasObert());
    }
    @Test
    public void testUllDeGatResponCorrectamentQuanObre() {
        UllDeGat ull = new UllDeGat();
        String resposta = ull.obret();
        Assert.assertTrue(ull.estasObert());
        Assert.assertEquals("nyeek", resposta);
    }
    @Test
    public void testUllDeGatResponCorrectamentQuanTanca() {
        UllDeGat ull = new UllDeGat(true);
        String resposta = ull.tancat();
        Assert.assertFalse(ull.estasObert());
        Assert.assertEquals("plonx", resposta);
    }
    @Test
    public void testUllDeGatNoResponQuanLiDemanenObretIJaObert() {
        UllDeGat ull = new UllDeGat(true);
        String resposta = ull.obret();
        Assert.assertTrue(ull.estasObert());
        Assert.assertTrue(resposta.isEmpty());
    }
    @Test
    public void testUllDeGatNoResponQuanLiDemanenTancarIJaTancat() {
        UllDeGat ull = new UllDeGat();
        String resposta = ull.tancat();
        Assert.assertFalse(ull.estasObert());
        Assert.assertTrue(resposta.isEmpty());
    }
}

