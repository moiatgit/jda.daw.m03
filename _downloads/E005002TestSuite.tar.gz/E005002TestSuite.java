/*
 * Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 2. Els ulls de gat
 * Suite for all the test classes in this exercise
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runner.JUnitCore;

@RunWith(Suite.class)

@Suite.SuiteClasses( { 
    E005002UllDeGatTest.class,
    E005002PicarolTest.class, E005002GatRenatTest.class })

public class E005002TestSuite {
    public static void main(String[] arrstring) {
        JUnitCore.main(new String[]{"E005002TestSuite"});
    }
}
