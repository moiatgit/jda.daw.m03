/*
 * Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 2. Els ulls de gat
 * Note: is the very same test as in exercise 1
 */
import org.junit.Assert;
import org.junit.Test;
public class E005002PicarolTest {
    @Test
    public void testPicarolSonaIComptaFinsATres() {
        Picarol picarol = new Picarol();
        Assert.assertEquals(0, picarol.quantsCopsHaSonat());
        for (int i = 1; i <=3; i++) {
            picarol.sona();
            Assert.assertEquals(i, picarol.quantsCopsHaSonat());
        }
    }
}
