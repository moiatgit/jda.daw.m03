/* Secció: Elements essencials
 * Entrada: Relacions: agregació
 * Exercici: 2. Els ulls de gat
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.JUnitCore;

public class E005002GatRenatTest {
    @Test
    public void testRenatNeixEstirat() {
        Assert.assertEquals("estirat", new GatRenat().getEstatComString());
    }
    @Test
    public void testRenatPotEstarDret() {
        GatRenat renat = new GatRenat();
        renat.setEstat("dret");
        Assert.assertEquals("dret", renat.getEstatComString());
    }
    @Test
    public void testRenatPotEstarAssegut() {
        GatRenat renat = new GatRenat();
        renat.setEstat("assegut");
        Assert.assertEquals("assegut", renat.getEstatComString());
    }
    @Test
    public void testRenatPotEstirarse() {
        GatRenat renat = new GatRenat();
        renat.setEstat("assegut");
        renat.setEstat("estirat");
        Assert.assertEquals("estirat", renat.getEstatComString());
    }
    @Test
    public void testRenaNoPotCorrer() {
        GatRenat renat = new GatRenat();
        renat.setEstat("corrent");
        Assert.assertEquals("estirat", renat.getEstatComString());
    }
    @Test
    public void testRenatNeixViu() {
        Assert.assertTrue(new GatRenat().estaViu());
    }
    @Test
    public void testRenatNoEstaViuAmbZeroVides() {
        GatRenat renat = new GatRenat();
        renat.setVides(0);
        Assert.assertFalse(renat.estaViu());
    }
    @Test
    public void testRenatDiuEstarEstiratEnNeixer() {
        Assert.assertTrue(new GatRenat().estaEstirat());
    }
    @Test
    public void testRenatDiuNoEstarEstiratQuanDret() {
        GatRenat renat = new GatRenat();
        renat.setEstat("dret");
        Assert.assertFalse(renat.estaEstirat());
    }
    @Test
    public void testRenatDiuEstarAssegutQuanHoEsta() {
        GatRenat renat = new GatRenat();
        renat.setEstat("assegut");
        Assert.assertTrue(renat.estaAssegut());
    }
    @Test
    public void testRenatDiuNoEstarAssegutQuanNoHoEsta() {
        Assert.assertFalse(new GatRenat().estaAssegut());
    }
    @Test
    public void testRenatDiuEstarDretQuanHoEsta() {
        GatRenat renat = new GatRenat();
        renat.setEstat("dret");
        Assert.assertTrue(renat.estaDret());
    }
    @Test
    public void testRenatDiuNoEstarDretQuanNoHoEsta() {
        Assert.assertFalse(new GatRenat().estaDret());
    }

    @Test
    public void testRenatSEstira() {
        GatRenat renat = new GatRenat();
        renat.setEstat("dret");
        String resposta = renat.estirat();
        Assert.assertTrue(renat.estaEstirat());
        Assert.assertEquals("m'estiro", resposta);
    }
    @Test
    public void testRenatSeu() {
        GatRenat renat = new GatRenat();
        String resposta = renat.seu();
        Assert.assertTrue(renat.estaAssegut());
        Assert.assertEquals("m'assec", resposta);
    }
    @Test
    public void testRenatSAixeca() {
        GatRenat renat = new GatRenat();
        String resposta = renat.aixecat();
        Assert.assertTrue(renat.estaDret());
        Assert.assertEquals("m'aixeco", resposta);
    }
    @Test
    public void testRenatNoFaResQuanDemanemQueSEstiriIJaHoEstava() {
        GatRenat renat = new GatRenat();
        String resposta = renat.estirat();
        Assert.assertEquals("no faig res", resposta);
    }
    @Test
    public void testRenatNoFaResQuanDemanemQueSAsseguiIJaHoEstava() {
        GatRenat renat = new GatRenat();
        renat.seu();
        String resposta = renat.seu();
        Assert.assertEquals("no faig res", resposta);
    }

    @Test
    public void testRenatNoFaResQuanDemanemQueSAixequiIJaHoEstava() {
        GatRenat renat = new GatRenat();
        renat.aixecat();
        String resposta = renat.aixecat();
        Assert.assertEquals("no faig res", resposta);
    }

    @Test
    public void testRenatCanviaEstatAmbGatEstat() {
        GatRenat renat = new GatRenat();
        renat.setEstat(GatEstat.ESTIRAT);
        renat.setEstat(GatEstat.ASSEGUT);
        renat.setEstat(GatEstat.DRET);
        Assert.assertEquals(GatEstat.DRET, renat.getEstat());
    }

    @Test
    public void testRenatNeixDret() {
        GatRenat renat = new GatRenat(GatEstat.DRET);
        Assert.assertEquals(GatEstat.DRET, renat.getEstat());
    }

    @Test
    public void testRenatNoTePicarolEnNeixer() {
        GatRenat renat = new GatRenat();
        Assert.assertFalse(renat.tePicarol());
    }

    @Test
    public void testRenatAcceptaPicarol() {
        GatRenat renat = new GatRenat();
        Picarol picarol = new Picarol();
        Picarol anticPicarol = renat.posaPicarol(picarol);
        Assert.assertNull(anticPicarol);
    }

    @Test
    public void testRenatRetornaPicarolAnteriorEnAcceptarUnDeNou() {
        GatRenat renat = new GatRenat();
        Picarol picarol1 = new Picarol();
        Picarol picarol2 = new Picarol();
        renat.posaPicarol(picarol1);
        Picarol anticPicarol = renat.posaPicarol(picarol2);
        Assert.assertEquals(picarol1, anticPicarol);
    }

    @Test
    public void testRenatTreuPicarol() {
        GatRenat renat = new GatRenat();
        Picarol picarol = new Picarol();
        renat.posaPicarol(picarol);
        Picarol anticPicarol = renat.treuPicarol();
        Assert.assertEquals(picarol, anticPicarol);
    }

    @Test
    public void testRenatFaSonarElPicarolQuanEsMou() {
        GatRenat renat = new GatRenat();
        Picarol picarol = new Picarol();
        renat.posaPicarol(picarol);
        renat.seu();
        Assert.assertEquals(1, picarol.quantsCopsHaSonat());
        renat.aixecat();
        Assert.assertEquals(2, picarol.quantsCopsHaSonat());
        renat.estirat();
        Assert.assertEquals(3, picarol.quantsCopsHaSonat());
    }

    @Test
    public void testRenatNoFaSonarElPicarolQuanNoEsMou() {
        GatRenat renat = new GatRenat(GatEstat.ESTIRAT);
        Picarol picarol = new Picarol();
        renat.posaPicarol(picarol);
        renat.estirat();    // no ha de sonar
        Assert.assertEquals(0, picarol.quantsCopsHaSonat());
        renat.aixecat();
        renat.aixecat();
        Assert.assertEquals(1, picarol.quantsCopsHaSonat());
        renat.seu();
        renat.seu();
        Assert.assertEquals(2, picarol.quantsCopsHaSonat());
    }

    @Test
    public void testRenatTeElsUllsTancatsQuanNeixEstirat() {
        GatRenat renat = new GatRenat();
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeUllDretObertIUllEsquerreTancatQuanNeixAssegut() {
        GatRenat renat = new GatRenat(GatEstat.ASSEGUT);
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeElsUllsObertsQuanNeixDret() {
        GatRenat renat = new GatRenat(GatEstat.DRET);
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeElsUllsTancatsQuanEstirat() {
        GatRenat renat = new GatRenat(GatEstat.DRET);
        renat.estirat();
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeUllDretObertIUllEsquerreTancatQuanSeu() {
        GatRenat renat = new GatRenat();
        renat.seu();
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeUllsObertsQuanAixecat() {
        GatRenat renat = new GatRenat();
        renat.aixecat();
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeElsUllsTancatsQuanSetEstatEstirat() {
        GatRenat renat = new GatRenat(GatEstat.DRET);
        renat.setEstat(GatEstat.ESTIRAT);
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeUllDretObertIUllEsquerreTancatQuanSetEstatAssegut() {
        GatRenat renat = new GatRenat();
        renat.setEstat(GatEstat.ASSEGUT);
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeUllsObertsQuanSetEstatDret() {
        GatRenat renat = new GatRenat();
        renat.setEstat(GatEstat.DRET);
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeElsUllsTancatsQuanSetEstatEstiratAmbString() {
        GatRenat renat = new GatRenat(GatEstat.DRET);
        renat.setEstat("estirat");
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertFalse("L'ull dret s'esperava tancat", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeUllDretObertIUllEsquerreTancatQuanSetEstatAssegutAmbString() {
        GatRenat renat = new GatRenat();
        renat.setEstat("assegut");
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatTeUllsObertsQuanSetEstatDretAmbString() {
        GatRenat renat = new GatRenat();
        renat.setEstat("dret");
        UllDeGat ullDret = renat.getUllDret();
        UllDeGat ullEsquerre = renat.getUllEsquerre();
        Assert.assertTrue("L'ull dret s'esperava obert", ullDret.estasObert());
        Assert.assertTrue("L'ull esquerre s'esperava obert", ullEsquerre.estasObert());
    }

    @Test
    public void testRenatGetUllsLliurenUnaCopia() {
        GatRenat renat = new GatRenat();
        UllDeGat ullDretInicial = renat.getUllDret();
        UllDeGat ullEsquerreInicial = renat.getUllEsquerre();

        ullDretInicial.obret();
        ullEsquerreInicial.obret();

        UllDeGat ullDretFinal = renat.getUllDret();
        UllDeGat ullEsquerreFinal = renat.getUllEsquerre();

        Assert.assertFalse("L'ull dret s'esperava tancat", ullDretFinal.estasObert());
        Assert.assertFalse("L'ull esquerre s'esperava tancat", ullEsquerreFinal.estasObert());
    }

}
