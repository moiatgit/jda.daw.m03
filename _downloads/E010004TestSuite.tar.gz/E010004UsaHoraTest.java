/* Secció: Elements essencials
 * Entrada: Excepcions
 * Exercici: 4. Incondicional
 */
import org.junit.runner.JUnitCore;
import org.junit.Test;
import org.junit.Assert;

public class E010004UsaHoraTest {

    @Test
    public void testProcessaEntrada_controlaCapArgument() {
        String resposta = UsaHora.processaEntrada(new String[] { });
        Assert.assertEquals("java.lang.ArrayIndexOutOfBoundsException: 0", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaPrimerArgumentNoNumèric() {
        String resposta = UsaHora.processaEntrada(new String[] { "a" });
        Assert.assertEquals("java.lang.NumberFormatException: For input string: \"a\"", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaPrimerArgumentNumèric() {
        String resposta = UsaHora.processaEntrada(new String[] { "1" });
        Assert.assertEquals("java.lang.ArrayIndexOutOfBoundsException: 1", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaSegonArgumentNoNumèric() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "b" });
        Assert.assertEquals("java.lang.NumberFormatException: For input string: \"b\"", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaSegonArgumentNumèric() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "2" });
        Assert.assertEquals("java.lang.ArrayIndexOutOfBoundsException: 2", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaTercerArgumentNoNumèric() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "2", "c" });
        Assert.assertEquals("java.lang.NumberFormatException: For input string: \"c\"", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaEntradaCorrecta() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "2", "3" });
        Assert.assertEquals("1:02:04", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaEntradaHoresMassaAlt() {
        String resposta = UsaHora.processaEntrada(new String[] { "24", "2", "3" });
        Assert.assertEquals("java.lang.IllegalArgumentException: Hora(24, 2, 3) fora de rang", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaEntradaHoresNegatiu() {
        String resposta = UsaHora.processaEntrada(new String[] { "-1", "2", "3" });
        Assert.assertEquals("java.lang.IllegalArgumentException: Hora(-1, 2, 3) fora de rang", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaEntradaMinutsMassaAlt() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "60", "3" });
        Assert.assertEquals("java.lang.IllegalArgumentException: Hora(1, 60, 3) fora de rang", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaEntradaMinutsNegatiu() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "-2", "3" });
        Assert.assertEquals("java.lang.IllegalArgumentException: Hora(1, -2, 3) fora de rang", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaEntradaSegonsMassaAlt() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "2", "60" });
        Assert.assertEquals("java.lang.IllegalArgumentException: Hora(1, 2, 60) fora de rang", resposta);
    }

    @Test
    public void testProcessaEntrada_controlaEntradaSegonsNegatiu() {
        String resposta = UsaHora.processaEntrada(new String[] { "1", "2", "-3" });
        Assert.assertEquals("java.lang.IllegalArgumentException: Hora(1, 2, -3) fora de rang", resposta);
    }


    public static void main(String[] args) {
        JUnitCore.main(new String[]{"E010004UsaHoraTest"});
    }
}
