/*
 * Secció: Elements essencials
 * Entrada: Excepcions
 * Exercici: 4. Incondicional
 */
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runner.JUnitCore;

@RunWith(Suite.class)

@Suite.SuiteClasses( { 
    E010004HoraTest.class,
    E010004UsaHoraTest.class
})

public class E010004TestSuite {
    public static void main(String[] arrstring) {
        JUnitCore.main(new String[]{"E010004TestSuite"});
    }
}
