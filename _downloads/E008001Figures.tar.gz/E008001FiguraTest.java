/* Secció: Elements essencials
 * Entrada: Classes abstractes
 * Exercici: 1. Figures
 */
import org.junit.Assert;
import org.junit.Test;
import org.junit.Before;
import org.junit.runner.JUnitCore;

public class E008001FiguraTest {

    @Test
    public void testFigura_esAbstracta() {
        Assert.assertTrue("La classe Figura ha de ser abstracta", TestUtils.isAbstractClass(Figura.class));
        Assert.assertTrue("El mètode Double getArea() ha de ser abstracte", TestUtils.hasAbstractMethod(Figura.class, "getArea", new String[] {}));
        Assert.assertTrue("El mètode Double getPerimetre() ha de ser abstracte", TestUtils.hasAbstractMethod(Figura.class, "getPerimetre", new String[] {}));
    }

    @Test
    public void testFigura_subclassesBenDefinides() {
        /* les subclasses no tenen constructors per defecte */
        Assert.assertFalse(TestUtils.hasPublicDefaultConstructor(Quadrat.class));
        Assert.assertFalse(TestUtils.hasPublicDefaultConstructor(Rectangle.class));
        Assert.assertFalse(TestUtils.hasPublicDefaultConstructor(TriangleRectangle.class));
        Assert.assertFalse(TestUtils.hasPublicDefaultConstructor(Cercle.class));

        /* les subclasses tenen els constructors específics */
        Figura[] figures = {
            new Quadrat(10.1),
            new Rectangle(10.2, 10.3),
            new Cercle(10.4),
            new TriangleRectangle(10.5, 10.6)
        };

        /* les subclasses declaren adequadament les seves propietats com a privades i
         * finals */
        Assert.assertTrue(TestUtils.declaresOnlyNonPublicFinalFields(Quadrat.class));
        Assert.assertTrue(TestUtils.declaresOnlyNonPublicFinalFields(Rectangle.class));
        Assert.assertTrue(TestUtils.declaresOnlyNonPublicFinalFields(TriangleRectangle.class));
        Assert.assertTrue(TestUtils.declaresOnlyNonPublicFinalFields(Cercle.class));


        /* les subclasses emmagatzemen correctament els valors amb que es construeixen */
        assertDoubleValueEquals(10.1, ((Quadrat)figures[0]).getCostat());
        assertDoubleValueEquals(10.2, ((Rectangle)figures[1]).getBase());
        assertDoubleValueEquals(10.3, ((Rectangle)figures[1]).getAltura());
        assertDoubleValueEquals(10.4, ((Cercle)figures[2]).getRadi());
        assertDoubleValueEquals(10.5, ((TriangleRectangle)figures[3]).getBase());
        assertDoubleValueEquals(10.6, ((TriangleRectangle)figures[3]).getAltura());

        /* les subclasses realitzen correctament els càlculs */
        assertDoubleValueEquals(102.01, figures[0].getArea());
        assertDoubleValueEquals(40.4, figures[0].getPerimetre());
        assertDoubleValueEquals(105.06, figures[1].getArea());
        assertDoubleValueEquals(41.0, figures[1].getPerimetre());
        assertDoubleValueEquals(339.79466141, figures[2].getArea());
        assertDoubleValueEquals(65.34512719, figures[2].getPerimetre());
        assertDoubleValueEquals(55.65, figures[3].getArea());
        assertDoubleValueEquals(36.02012064, figures[3].getPerimetre());
    }

    private void assertDoubleValueEquals(double expected, double obtained) {
        Assert.assertTrue("S'esperava " + expected + " però s'ha trobat " + obtained, 
                TestUtils.fuzzyEqualDouble(expected, obtained));
    }

    public static void main(String[] args) {
        JUnitCore.main(new String[]{"E008001FiguraTest"});
    }
}

