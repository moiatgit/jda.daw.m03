/*
 * A bunch of testing utilities
 *
 * This class is not aimed to be understood by M03 Students so, if you're one of them but have
 * curiosity, just take it easy while studying this code.
 */

import java.lang.reflect.Modifier;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;

class TestUtils {

    static boolean isAbstractClass(Class classInstance) {
        return Modifier.isAbstract(classInstance.getModifiers());
    }

    /**
     * Checks whether the class has an abstract method named methodName with args
     * arguments
     * @param classInstance: the corresponding class
     * @param methodName: the name of the expected method
     * @param args: an array (possibly empty) of non null non empty strings
     *              each one representing the name of a type
     * @return true if the class contains such a method
     */
    static boolean hasAbstractMethod(Class classInstance, String methodName, String[] args) {
        for (Method method: classInstance.getDeclaredMethods()) {
            if (! method.getName().equals(methodName)) { continue; }
            if (! Modifier.isAbstract(method.getModifiers())) { continue; }
            Class<?>[] typesFound = method.getParameterTypes();
            if (typesFound.length != args.length) { continue; }
            boolean typesMatch = true;
            for (int i=0; i<typesFound.length; i++) {
                if (! typesFound[i].getName().equals(args[i])) {
                    typesMatch = false;
                    break;
                }
            }
            if (typesMatch) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks whether the class contains only non public final fields
     * @param classInstance: the corresponding class
     * @return true if the class doesn't contain any public field and all the fields are
     * declared as final
     */
    static boolean declaresOnlyNonPublicFinalFields(Class classInstance) {
        for (Field field: classInstance.getDeclaredFields()) {
            if (Modifier.isPublic(field.getModifiers()) || ! Modifier.isFinal(field.getModifiers())) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns true if the given class has a public constructor with the specified types as params
     * Note: if args is an empty array, the method checks for the default constructor
     * @param classInstance: the corresponding class
     * @param args is an array (possibly empty) of non null non empty strings
     *                          each one representing the name of a type
     */
    static boolean hasAPublicConstructorWithTypeNamesAsParameters(Class<?> classInstance, String[] args) {
        for (Constructor<?> constructor: classInstance.getDeclaredConstructors()) {
            if (Modifier.isPrivate(constructor.getModifiers())) { continue; }
            Class<?>[] typesFound = constructor.getParameterTypes();
            if (typesFound.length != args.length) { continue; }
            boolean typesMatch = true;
            for (int i=0; i<typesFound.length; i++) {
                if (! typesFound[i].getName().equals(args[i])) {
                    typesMatch = false;
                    break;
                }
            }
            if (typesMatch) { return true; }
        }
        return false;
    }


    /**
     * Returns true if the given class has a public default constructor
     * @param classInstance: the corresponding class
     */
    static boolean hasPublicDefaultConstructor(Class<?> classInstance) {
        return hasAPublicConstructorWithTypeNamesAsParameters(classInstance, new String[] {});
    }

    /**
     * Checks whether the two double values are equals within a delta
     * @param v1: first value
     * @param v2: second value
     * @param delta: precission margin
     * @return: true if |v1 - v2| <= delta
     *
     */
    static boolean fuzzyEqualDouble(double v1, double v2, double delta) {
        return Math.abs(v1 - v2) <= delta;
    }

    /**
     * Checks whether the two double values are equals within a default delta
     * @param v1: first value
     * @param v2: second value
     * @return: true if |v1 - v2| <= defaultDelta
     *
     */
    static boolean fuzzyEqualDouble(double v1, double v2) {
        final double defaultDelta = 0.00001;
        return fuzzyEqualDouble(v1, v2, defaultDelta);
    }

}
